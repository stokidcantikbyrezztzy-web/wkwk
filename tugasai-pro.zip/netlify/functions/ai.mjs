export default async (request) => {
  const headers = {
    "Content-Type": "application/json",
    "Cache-Control": "no-store",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS"
  };
  if (request.method === "OPTIONS") return new Response(null, { status: 204, headers });
  if (request.method !== "POST") return new Response(JSON.stringify({ error: "Gunakan metode POST." }), { status: 405, headers });
  const apiKey = Netlify.env.get("OPENAI_API_KEY");
  if (!apiKey) return new Response(JSON.stringify({ error: "API key belum diatur. Tambahkan OPENAI_API_KEY di environment variables Netlify." }), { status: 500, headers });
  try {
    const body = await request.json();
    const prompt = String(body.prompt || "").slice(0, 12000);
    if (!prompt && !body.imageData) return new Response(JSON.stringify({ error: "Soal atau gambar wajib diisi." }), { status: 400, headers });
    const content = [{ type: "input_text", text: prompt || "Baca soal dari gambar dan bantu jelaskan jawabannya dalam bahasa Indonesia." }];
    if (body.imageData) {
      const type = ["image/png", "image/jpeg", "image/webp"].includes(body.imageType) ? body.imageType : "image/jpeg";
      if (String(body.imageData).length > 7_000_000) return new Response(JSON.stringify({ error: "Gambar terlalu besar." }), { status: 413, headers });
      content.push({ type: "input_image", image_url: `data:${type};base64,${body.imageData}` });
    }
    const upstream = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: { "Authorization": `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "gpt-4.1-mini",
        instructions: "Kamu adalah asisten belajar yang ramah untuk siswa. Jawab dalam bahasa Indonesia yang mudah dipahami. Bantu memahami konsep dan langkah pengerjaan; jangan mengarang jika informasi kurang. Untuk soal sekolah, berikan penjelasan yang akurat dan ringkas.",
        input: [{ role: "user", content }],
        max_output_tokens: 1200
      })
    });
    const result = await upstream.json();
    if (!upstream.ok) {
      const message = result?.error?.message || "Layanan AI gagal memproses permintaan.";
      return new Response(JSON.stringify({ error: message }), { status: upstream.status, headers });
    }
    let answer = result.output_text;
    if (!answer && Array.isArray(result.output)) {
      answer = result.output.flatMap(item => item.content || []).filter(c => c.type === "output_text").map(c => c.text).join("\n");
    }
    return new Response(JSON.stringify({ answer: answer || "AI belum menghasilkan jawaban teks." }), { status: 200, headers });
  } catch (e) {
    return new Response(JSON.stringify({ error: "Permintaan tidak dapat diproses. Periksa konfigurasi dan coba lagi." }), { status: 500, headers });
  }
};