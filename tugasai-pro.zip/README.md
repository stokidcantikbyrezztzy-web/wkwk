# TugasAI — proyek Netlify

## Fitur
- Buka link tugas pada tab baru.
- Mode AI terintegrasi melalui Netlify Function dan OpenAI Responses API.
- Kirim teks soal atau screenshot PNG/JPEG/WEBP.
- Respons AI, salin percakapan, dan bersihkan chat.
- API key disimpan sebagai environment variable server, bukan di HTML.

## Deploy
1. Ekstrak ZIP ini.
2. Masuk ke Netlify dan buat site baru dengan mengunggah folder proyek melalui metode deploy yang mendukung Netlify Functions, atau hubungkan repository Git.
3. Pastikan `index.html`, `netlify.toml`, dan `netlify/functions/ai.mjs` berada di struktur yang sama seperti ZIP.
4. Di Netlify: Site configuration → Environment variables, tambahkan:
   - Key: `OPENAI_API_KEY`
   - Value: API key OpenAI milikmu.
5. Deploy/redeploy situs. Uji Mode AI dengan pertanyaan sederhana.

## Penting
- Kamu perlu API key OpenAI dan akun/API billing yang sesuai. Penggunaan API dapat dikenai biaya; cek harga dan limit sebelum digunakan.
- Jangan pernah menaruh API key di `index.html` atau membagikannya.
- Link tugas dibuka di tab baru. Situs tidak dapat otomatis membaca semua halaman (terutama halaman login/Google Forms) karena batasan browser dan akses situs. Untuk soal seperti itu, salin teks soal atau unggah screenshot.
- Website ini tidak mengirim atau mengisi formulir guru secara otomatis.
- Jangan unggah data sensitif.
